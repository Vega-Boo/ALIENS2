﻿
using var game = new ALIENS__2.Game1();
game.Run();
